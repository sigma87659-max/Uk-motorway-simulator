# UK Motorway Sim – Android app

A WebView wrapper around the game (`app/src/main/assets/index.html`). Rotates freely (portrait/landscape), runs fullscreen, Back button opens the menu.

## Get the APK (no Android Studio needed)
1. Create a free GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab -> **Build APK** -> wait ~3 min.
3. Open the finished run -> download **UK-Motorway-Sim-apk** -> unzip -> install `app-debug.apk`
   (allow "install unknown apps" for your browser/files app when asked).

The workflow downloads three.js into the app so the game works offline.

## Build locally instead
Download https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js into `app/src/main/assets/three.min.js`,
open this folder in Android Studio and run **Build > Build APK(s)**.
(Without that file the app still works, but needs internet to fetch three.js.)
